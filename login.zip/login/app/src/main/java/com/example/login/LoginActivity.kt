package com.example.login

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var tvError: TextView
    private lateinit var btnRole: Button
    private lateinit var btnLogin: Button
    private lateinit var btnRegister: Button
    private var selectedRole: String? = null

    // Instancia de FirebaseAuth
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Inicializa FirebaseAuth
        auth = FirebaseAuth.getInstance()

        // Inicializa los elementos de la UI
        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        tvError = findViewById(R.id.tvError)
        btnRole = findViewById(R.id.btnRole)
        btnLogin = findViewById(R.id.btnLogin)
        btnRegister = findViewById(R.id.btnRegister)

        // Configura el botón para seleccionar rol
        btnRole.setOnClickListener {
            showRoleSelectionDialog()
        }

        // Configura el botón para iniciar sesión
        btnLogin.setOnClickListener {
            login()
        }

        // Configura el botón para añadir usuario
        btnRegister.setOnClickListener {
            registerUser()
        }
    }

    private fun showRoleSelectionDialog() {
        val roles = arrayOf("Médico", "Usuario")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Seleccionar Rol")
            .setSingleChoiceItems(roles, -1) { dialog, which ->
                selectedRole = roles[which]
            }
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                btnRole.text = selectedRole ?: "Seleccionar Rol"
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
        builder.create().show()
    }

    private fun login() {
        val username = etUsername.text.toString()
        val password = etPassword.text.toString()

        if (username.isNotEmpty() && password.isNotEmpty() && selectedRole != null) {
            val isPasswordCorrect = validatePassword(password)
            if (isPasswordCorrect) {
                tvError.visibility = TextView.GONE
                Toast.makeText(this, "Bienvenido, $selectedRole $username", Toast.LENGTH_SHORT).show()
            } else {
                tvError.visibility = TextView.VISIBLE
                tvError.text = "Contraseña incorrecta"
            }
        } else {
            Toast.makeText(this, "Por favor completa todos los campos y selecciona un rol", Toast.LENGTH_SHORT).show()
        }
    }

    private fun registerUser() {
        val email = etUsername.text.toString()
        val password = etPassword.text.toString()

        if (email.isNotEmpty() && password.isNotEmpty()) {
            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Registro exitoso
                        Toast.makeText(this, "Usuario registrado exitosamente", Toast.LENGTH_SHORT).show()
                    } else {
                        // Error en el registro
                        Toast.makeText(this, "Error al registrar usuario: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                    }
                }
        } else {
            Toast.makeText(this, "Por favor ingresa un email y una contraseña", Toast.LENGTH_SHORT).show()
        }
    }

    private fun validatePassword(password: String): Boolean {
        return password == "1234" // Ejemplo de validación de contraseña
    }
}
